extern void yyerror(char *);
extern int yylex(void);
extern int yyparse(void);
#ifdef __cplusplus
extern "C" {
#endif
   extern int yywrap(void);
#ifdef __cplusplus
        }
#endif
