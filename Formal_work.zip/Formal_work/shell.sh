make clean
make
./a.out<lll.rust