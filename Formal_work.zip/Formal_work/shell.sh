make clean
make
./a.out<fib.rust