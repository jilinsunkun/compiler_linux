make clean
make
./a.out<exampe.rust